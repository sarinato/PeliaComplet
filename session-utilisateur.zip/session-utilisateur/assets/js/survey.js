// $('.nav-link').click(function (e) {
// 	if ($(".mm-survey-container").hasClass("active") == true) {
// 		$(".mm-survey-container").removeClass("active show");

// 	}
// 	var attr = $(e.target).attr("href");
// 	var id = attr.slice(1, 6);
// 	$("#" + id).addClass("active show");
// 	if ($("#" + id).hasClass("active show")) {
// 		alert("yeees");
// 	}
// });