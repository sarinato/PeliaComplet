
	
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="../assets/js/jquery-3.2.1.min.js"></script>
	<script src="../assets/js/popper.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/stellar.js"></script>
	<script src="../assets/js/jquery.magnific-popup.min.js"></script>

	<script src="../vendors/lightbox/simpleLightbox.min.js"></script>
	<script src="../vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="../vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="../vendors/jquery-ui/jquery-ui.js"></script>
	<script src="../assets/js/jquery.ajaxchimp.min.js"></script>
	<script src="../vendors/counter-up/jquery.waypoints.min.js"></script>
	<script src="../vendors/counter-up/jquery.counterup.js"></script>
	<script src="../assets/js/mail-script.js"></script>
	<!--gmaps Js-->

	<script src="../assets/js/theme.js"></script>
	

	 <!-- Jquery JS-->
	 <script src="../vendors/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="../vendors/select2/select2.min.js"></script>
    <script src="../vendors/datepicker/moment.min.js"></script>
	<script src="../vendors/datepicker/daterangepicker.js"></script>
	


    <!-- Main JS-->
	<script src="../assets/js/global.js"></script>
	<script src="../assets/js/medecin.js"></script>