	<!-- Required meta tags -->

	<link rel="stylesheet" type="text/css" href="../dist/timepicker.min.css">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../assets/css/bootstrap.css">
	<link rel="stylesheet" href="../vendors/linericon/style.css">
	<link rel="stylesheet" href="../assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/css/magnific-popup.css">
	<link rel="stylesheet" href="../vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="../vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="../vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="../vendors/jquery-ui/jquery-ui.css">
	<link rel="stylesheet" href="../vendors/animate-css/animate.css">
	<link href="../assets/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="../vendors/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <link href="../vendors/select2/select2.min.css" rel="stylesheet" media="all">
	<link href="../vendors/datepicker/daterangepicker.css" rel="stylesheet" media="all">

	<!-- main css -->
	<link rel="stylesheet" href="../assets/css/style.css">
	<link rel="stylesheet" href="../assets/css/mainn.css">
	

	 
