<!--
 * @fileName comm.html
 * @author Amir <amirsanni@gmail.com>
 * @date 22-Dec-2016
 */
-->
<?php 
    include("../config/verificationLogin.php");
    require("../config/connect.php");
?>

<!DOCTYPE html>
<html lang="en">
    <head>    
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Pelia Chat</title>
        
        <!-- Favicon -->
        <link rel="shortcut icon" href="../assets/img/pelia.png">
        <!-- favicon ends -->
        
        <!--- LOAD FILES -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.0.8/font-awesome-animation.min.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!-- Custom styles -->
        <link rel="stylesheet" href="css/comm.css">
        <!-- <link rel="stylesheet" href="../assets/css/mainn.css"> -->
        

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
                <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
                <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    
    
    <body>
  
    <div class="all">
        <div class="container-fluid">
            <div class="row">
                <!-- Remote Video -->
                <video id="peerVid" poster="img/vidbg.png" playsinline autoplay></video>
                <!-- Remote Video -->
            </div>
            
            <div class="row margin-top-20"> 
                <!-- Timer -->
                <div class="col-sm-12 text-center margin-top-5" style="color:#fff;margin-bottom:1%">
                    <span id="countHr"></span>H:
                    <span id="countMin"></span>M:
                    <span id="countSec"></span>S
                </div>
                <!-- Timer -->               
                <!-- Call Buttons -->
                <div class="col-sm-12 text-center" id="callBtns">
                    <button style="border-radius:50%;" class="btn btn-success initCall botona" id="initAudio"><i class="fa fa-phone"></i></button>
                    <button style="border-radius:50%;" class="btn btn-info  initCall botona" id="initVideo"><i class="fa fa-video-camera"></i></button>
                    <button style="border-radius:50%;" class="btn btn-danger botona " id="terminateCall" disabled><i class="fa fa-phone-square"></i></button>
                </div>
                <!-- Call Buttons -->
                
                
            </div>
            
            
            <!-- Local Video -->
            <div class="row">
                <div class="col-sm-12">
                    <video id="myVid" poster="img/vidbg.png" muted autoplay></video>
                </div>
            </div>
            <!-- Local Video -->
        </div>

        <div  class="container-fluid chat-pane">
            <!-- CHAT PANEL-->
            <div class="row chat-window col-xs-12 col-md-4">
                <div class="">
                    <div style="border:none" class="panel panel-default chat-pane-panel">
                        <div style="background: #038dfe;color:#fff;border:none" class="panel-heading chat-pane-top-bar">
                            <div class="col-xs-10" style="margin-left:-20px">
                                <i style="position: relative;right: 1.5%;" class="fa fa-comment" id="remoteStatus"></i><?php echo $_SESSION['prenom']; ?>
                                <b id="remoteStatusTxt">(Déconnecté)</b>
                            </div>
                            <div class="col-xs-2 pull-right">
                                <span id="minim_chat_window" class="panel-collapsed fa fa-plus icon_minim pointer"></span>
                            </div>
                        </div>
                        
                        <div class="panel-body msg_container_base" id="chats"></div>
                        
                        <div class="panel-footer">
                            <span id="typingInfo"></span>
                            <div class="input-group">
                                <input id="chatInput" type="text" class="form-control input-sm chat_input" placeholder="Tapez votre message ici...">
                                <span class="input-group-btn">
                                    <button class="btn btn-primary btn-sm" id="chatSendBtn">Envoyer</button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- CHAT PANEL -->
        </div>

        <!--Modal to show that we are calling-->
        <div id="callModal" class="modal">
            <div class="modal-content text-center">
                <div class="modal-header" id="callerInfo"></div>

                <div class="modal-body">
                    <button type="button" class="btn btn-danger btn-sm" id='endCall'>
                        <i class="fa fa-times-circle"></i> End Call
                    </button>
                </div>
            </div>
        </div>
        <!--Modal end-->


        <!--Modal to give options to receive call-->
        <div id="rcivModal" class="modal">
            <div class="modal-content">
                <div class="modal-header" id="calleeInfo"></div>

                <div class="modal-body text-center">
                    <button type="button" class="btn btn-success btn-sm answerCall" id='startAudio'>
                        <i class="fa fa-phone"></i> Audio Call
                    </button>
                    <button type="button" class="btn btn-success btn-sm answerCall" id='startVideo'>
                        <i class="fa fa-video-camera"></i> Video Call
                    </button>
                    <button type="button" class="btn btn-danger btn-sm" id='rejectCall'>
                        <i class="fa fa-times-circle"></i> Reject Call
                    </button>
                </div>
            </div>
        </div>
        <!--Modal end-->
        
        <!--Snackbar -->
        <div id="snackbar"></div>
        <!-- Snackbar -->
        </div>
        <!-- custom js -->
        <script src="js/config.js"></script>
        <script src="js/adapter.js"></script>
        <script src="js/comm.js"></script>
        <audio id="callerTone" src="media/callertone.mp3" loop preload="auto"></audio>
        <audio id="msgTone" src="media/msgtone.mp3" preload="auto"></audio>
    </body>
</html>